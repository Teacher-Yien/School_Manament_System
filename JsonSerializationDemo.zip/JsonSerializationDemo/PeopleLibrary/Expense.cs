﻿namespace PeopleLibrary;

public class Expense
{
    public string Description { get; set; } = "";
    public double Amount { get; set; }
}
