﻿#define IS_DB_DROPPED

using Shares;


namespace CreatingSchema.ConsoleApp;

internal class Program
{
    static void Main(string[] args)
    {
        Helper.DataSource = "localhost";
        Helper.DatabaseName = "enrolldb";

        //Connection to the data source
        if ( ConnectToDataSource() == false) return;
        Pause();

        #if IS_DB_DROPPED
        //Dropping database
        DropDatabase();
        Pause();
        #endif

        //Creating database
        CreateDatabase();
        Pause();
       
        //Changing the current database to specified database
        if (ChangeDatabase() == false) return;
        Pause();

        //Creating the table
        CreateTable(Helper.StudentTableName, Helper.StudentCommandText);
        Pause();

        //Creating the table
        CreateTable(Helper.CourseTableName, Helper.CourseCommandText);
        Pause();

        //Creating the table
        CreateTable(Helper.EnrollingTableName, Helper.EnrollingCommandText);
        Pause();
    }
    static void CreateTable(string tableName, string script)
    {
        var tables = Helper.Tables;
        Console.Write($"\nCurrent tables: {(tables.Count==0?"(NA)":tables.Aggregate((a,b)=>a+"; "+b))}");
       
        Console.WriteLine($"\nCreating new table {tableName}...");
        var result = Helper.CreateTable(tableName, script);
        Console.WriteLine(result.Message);
    }
    static bool ChangeDatabase()
    {
        Console.WriteLine($"\nCurrent database:{Helper.CurrentDatabase}");
        Console.WriteLine($"Changing the current database to {Helper.DatabaseName}...");
        var result = Helper.ChangeDatabase();
        Console.WriteLine(result.Message);
        return result.IsSucceded;
    }
    static bool CreateDatabase()
    {
        Console.WriteLine($"\nCreating a database named {Helper.DatabaseName}...");
        var result =Helper.CreateDatabase();
        Console.WriteLine(result.Message);
        return result.IsSucceded;
    }
    static void DropDatabase()
    {
        Console.WriteLine($"\nDropping the database named {Helper.DatabaseName}...");
        var result=Helper.DropDatabase();
        Console.WriteLine(result.Message);
    }
    static void Pause()
    {
        Console.Write("Any key to continue..."); 
        Console.ReadKey(); 
        Console.WriteLine();
    }
    static bool ConnectToDataSource()
    {
        Console.WriteLine("\nConnecting to the server...");
        var result = Helper.Connect();
        Console.WriteLine(result.Message);
        return result.IsSucceded;
    }
}

