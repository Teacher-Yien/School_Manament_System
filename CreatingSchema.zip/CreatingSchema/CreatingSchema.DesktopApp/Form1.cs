using Shares;

namespace CreatingSchema.DesktopApp;

public partial class Form1 : Form
{
    private Dictionary<string, string> scriptMap = new Dictionary<string, string>();
    public Form1()
    {
        InitializeComponent();
        grpComands.Enabled = false;
        txtDataSource.Text = Helper.DataSource;
        btnConnect.Click += DoClickConnect;
        btnDbCreate.Click += DoClickCreate;
        btnDbDrop.Click += DoClickDrop;
        btnDbChange.Click += DoClickChange;

       
        scriptMap.Add(Helper.StudentTableName, Helper.StudentCommandText);
        scriptMap.Add(Helper.CourseTableName, Helper.CourseCommandText);
        scriptMap.Add(Helper.EnrollingTableName, Helper.EnrollingCommandText);
        cboTables.SelectedValueChanged += DoSelectTable;
        cboTables.DataSource = scriptMap.Keys.ToArray();

        btnCreateTable.Click += DoClickCreateTable;
    }

    private void DoClickCreateTable(object? sender, EventArgs e)
    {
        if (txtCurDb.Text == "master")
        {
            MessageBox.Show("It is not allowed to create a table on the database, master",
                 "Creating database", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        var result = HandleAction(Helper.CreateTable,cboTables.SelectedValue.ToString()!, txtScript.Text);
        ShowMessageBox("Creating table", result);
        if (result.IsSucceded)
        {
            ShowTables();
        }
    }

    private void DoSelectTable(object? sender, EventArgs e)
    {
        txtScript.Text = scriptMap[cboTables.SelectedValue.ToString()!];
    }

    private void DoClickChange(object? sender, EventArgs e)
    {
        Helper.DatabaseName = txtWorkDb.Text;
        var result = HandleAction(Helper.ChangeDatabase);
        ShowMessageBox("Changing current database", result);
        if (result.IsSucceded)
        {
            txtCurDb.Text = Helper.CurrentDatabase;
            ShowTables();
        }
    }

    private void DoClickDrop(object? sender, EventArgs e)
    {
        Helper.DatabaseName = txtWorkDb.Text.Trim();
        if (new string[]{"master", "model", "msdb", "tempdb" }.Contains(Helper.DatabaseName))
        {
            MessageBox.Show("It is not allowed to drop system database", "Dropping database",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        var result = HandleAction(Helper.DropDatabase);
        ShowMessageBox("Dropping database", result);
    }

    private void DoClickCreate(object? sender, EventArgs e)
    {
        Helper.DatabaseName  = txtWorkDb.Text;
        var result = HandleAction(Helper.CreateDatabase);
        ShowMessageBox("Creating database", result);
    }

    private void DoClickConnect(object? sender, EventArgs e)
    {
        Helper.DataSource = txtDataSource.Text;
        HandleAction(Helper.Connect);
        var result = HandleAction(Helper.Connect);
        grpComands.Enabled = result.IsSucceded;
        txtCurDb.Text = Helper.CurrentDatabase;
        txtWorkDb.Text = Helper.DatabaseName;
        ShowMessageBox("Connecting", result);
        if (result.IsSucceded)
        {
            ShowTables();
        }
        
    }
    private void ShowTables()
    {
        txtTables.Text = Helper.Tables.Count == 0 ? "" : Helper.Tables.Aggregate((a, b) => a + "; " + b);
    }
    private Result HandleAction(Delegate action, params object[] args)
    {
        var curCursor = this.Cursor;
        this.Cursor = Cursors.WaitCursor;
        var result = action.DynamicInvoke(args) as Result??new();
        this.Cursor = curCursor;
        return result;
    }
    private void ShowMessageBox(string title, Result result)
    {
        if (result.IsSucceded == true)
        {
            MessageBox.Show(result.Message, title, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        else
        {
            MessageBox.Show(result.Message, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
