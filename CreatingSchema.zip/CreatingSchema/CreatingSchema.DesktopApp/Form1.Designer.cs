﻿namespace CreatingSchema.DesktopApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            btnConnect = new Button();
            txtDataSource = new TextBox();
            label1 = new Label();
            grpComands = new GroupBox();
            txtTables = new TextBox();
            label4 = new Label();
            btnDbChange = new Button();
            btnDbDrop = new Button();
            btnDbCreate = new Button();
            txtWorkDb = new TextBox();
            label3 = new Label();
            txtCurDb = new TextBox();
            label2 = new Label();
            label5 = new Label();
            cboTables = new ComboBox();
            txtScript = new TextBox();
            btnCreateTable = new Button();
            groupBox1.SuspendLayout();
            grpComands.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnConnect);
            groupBox1.Controls.Add(txtDataSource);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(643, 84);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            groupBox1.Text = "Connection";
            // 
            // btnConnect
            // 
            btnConnect.Location = new Point(376, 31);
            btnConnect.Name = "btnConnect";
            btnConnect.Size = new Size(94, 29);
            btnConnect.TabIndex = 4;
            btnConnect.Text = "Connect";
            btnConnect.UseVisualStyleBackColor = true;
            // 
            // txtDataSource
            // 
            txtDataSource.Location = new Point(112, 31);
            txtDataSource.Name = "txtDataSource";
            txtDataSource.Size = new Size(246, 27);
            txtDataSource.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(16, 34);
            label1.Name = "label1";
            label1.Size = new Size(90, 20);
            label1.TabIndex = 2;
            label1.Text = "Data Source";
            // 
            // grpComands
            // 
            grpComands.Controls.Add(btnCreateTable);
            grpComands.Controls.Add(txtScript);
            grpComands.Controls.Add(cboTables);
            grpComands.Controls.Add(label5);
            grpComands.Controls.Add(txtTables);
            grpComands.Controls.Add(label4);
            grpComands.Controls.Add(btnDbChange);
            grpComands.Controls.Add(btnDbDrop);
            grpComands.Controls.Add(btnDbCreate);
            grpComands.Controls.Add(txtWorkDb);
            grpComands.Controls.Add(label3);
            grpComands.Controls.Add(txtCurDb);
            grpComands.Controls.Add(label2);
            grpComands.Location = new Point(15, 107);
            grpComands.Name = "grpComands";
            grpComands.Size = new Size(640, 374);
            grpComands.TabIndex = 4;
            grpComands.TabStop = false;
            grpComands.Text = "Commands";
            // 
            // txtTables
            // 
            txtTables.Location = new Point(81, 108);
            txtTables.Name = "txtTables";
            txtTables.ReadOnly = true;
            txtTables.Size = new Size(544, 27);
            txtTables.TabIndex = 8;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(18, 110);
            label4.Name = "label4";
            label4.Size = new Size(50, 20);
            label4.TabIndex = 7;
            label4.Text = "Tables";
            // 
            // btnDbChange
            // 
            btnDbChange.Location = new Point(531, 64);
            btnDbChange.Name = "btnDbChange";
            btnDbChange.Size = new Size(94, 29);
            btnDbChange.TabIndex = 6;
            btnDbChange.Text = "Change";
            btnDbChange.UseVisualStyleBackColor = true;
            // 
            // btnDbDrop
            // 
            btnDbDrop.Location = new Point(428, 64);
            btnDbDrop.Name = "btnDbDrop";
            btnDbDrop.Size = new Size(94, 29);
            btnDbDrop.TabIndex = 5;
            btnDbDrop.Text = "Drop";
            btnDbDrop.UseVisualStyleBackColor = true;
            // 
            // btnDbCreate
            // 
            btnDbCreate.Location = new Point(326, 64);
            btnDbCreate.Name = "btnDbCreate";
            btnDbCreate.Size = new Size(94, 29);
            btnDbCreate.TabIndex = 4;
            btnDbCreate.Text = "Create";
            btnDbCreate.UseVisualStyleBackColor = true;
            // 
            // txtWorkDb
            // 
            txtWorkDb.Location = new Point(143, 64);
            txtWorkDb.Name = "txtWorkDb";
            txtWorkDb.Size = new Size(166, 27);
            txtWorkDb.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(13, 66);
            label3.Name = "label3";
            label3.Size = new Size(131, 20);
            label3.TabIndex = 2;
            label3.Text = "Working Database";
            // 
            // txtCurDb
            // 
            txtCurDb.Location = new Point(143, 31);
            txtCurDb.Name = "txtCurDb";
            txtCurDb.ReadOnly = true;
            txtCurDb.Size = new Size(166, 27);
            txtCurDb.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(13, 33);
            label2.Name = "label2";
            label2.Size = new Size(124, 20);
            label2.TabIndex = 0;
            label2.Text = "Current Database";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(23, 153);
            label5.Name = "label5";
            label5.Size = new Size(86, 20);
            label5.TabIndex = 9;
            label5.Text = "Table Script";
            // 
            // comboBox1
            // 
            cboTables.DropDownStyle = ComboBoxStyle.DropDownList;
            cboTables.FormattingEnabled = true;
            cboTables.Location = new Point(113, 150);
            cboTables.Name = "comboBox1";
            cboTables.Size = new Size(196, 28);
            cboTables.TabIndex = 10;
            // 
            // txtScript
            // 
            txtScript.Location = new Point(30, 183);
            txtScript.Multiline = true;
            txtScript.Name = "txtScript";
            txtScript.Size = new Size(595, 128);
            txtScript.TabIndex = 11;
            // 
            // btnCreateTable
            // 
            btnCreateTable.Location = new Point(509, 317);
            btnCreateTable.Name = "btnCreateTable";
            btnCreateTable.Size = new Size(116, 29);
            btnCreateTable.TabIndex = 12;
            btnCreateTable.Text = "Create Table";
            btnCreateTable.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(668, 495);
            Controls.Add(grpComands);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Creating Schema";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            grpComands.ResumeLayout(false);
            grpComands.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Button btnConnect;
        private TextBox txtDataSource;
        private Label label1;
        private GroupBox grpComands;
        private TextBox txtCurDb;
        private Label label2;
        private Button btnDbChange;
        private Button btnDbDrop;
        private Button btnDbCreate;
        private TextBox txtWorkDb;
        private Label label3;
        private TextBox txtTables;
        private Label label4;
        private Label label5;
        private Button btnCreateTable;
        private TextBox txtScript;
        private ComboBox cboTables;
    }
}
