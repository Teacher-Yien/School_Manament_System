﻿using Microsoft.Data.SqlClient;
using System.Data;
using System.Xml.Linq;

namespace Shares;

public static class Helper
{
    public static string DataSource { get; set; } = "localhost";
    public static string DatabaseName { get; set; } = "enrolldb";
    public static string ConnectionString => $"server={DataSource};trusted_connection=true;encrypt=false";

    public const string StudentTableName = "students";
    public const string CourseTableName = "courses";
    public const string EnrollingTableName = "enrollings";
    public static string StudentCommandText
        => $"create table {StudentTableName}(id varchar(36) primary key," +
           $"firstname nvarchar(30),lastname nvarchar(30),gender int null,age tinyint)";
    public static string CourseCommandText
        => $"create table {CourseTableName}(id varchar(36) primary key,code varchar(20) unique not null," +
           $"name nvarchar(30) not null)";
    public static string EnrollingCommandText
        => $"create table {EnrollingTableName}(id varchar(36) primary key," +
           $"studentid varchar(36),courseid varchar(36),begdate datetime,enddate datetime," +
           $"constraint FK_Enrollings_Students foreign key (studentid) references students(id) " +
           $"on update cascade on delete no action,constraint FK_Enrollings_Courses foreign key (courseid) " +
           $"references courses(id) on update cascade on delete no action)";

    public static string CreateDatabaseCommandText => $"create database {DatabaseName}";
    public static string DropDatabaseCommandText => $"drop database {DatabaseName}";

    private static SqlConnection? _connection = null;
    public static SqlConnection? Connection => _connection;
    public static string? CurrentDatabase => _connection?.Database;
    public static Result Connect()
    {
        _connection = new SqlConnection();
        _connection.ConnectionString = ConnectionString;
        try
        {
            _connection.Open();
            return new Result()
            {
                IsSucceded = true,
                Message = $"Successfully connected to server {DataSource}"
            };
        }
        catch (Exception ex)
        {
            _connection = null;
            return new Result()
            {
                IsSucceded = false,
                Message = $"Failed in connecting> {ex.Message}"
            };
        }
    }

    public static Result DropDatabase()
    {
        if (_connection == null)
        {
            return new Result()
            {
                IsSucceded = false,
                Message = "Connection is not available"
            };
        }
        var cmd = new SqlCommand();
        cmd.Connection = _connection;
        cmd.CommandText = DropDatabaseCommandText;
        cmd.CommandType = System.Data.CommandType.Text;
        try
        {
            cmd.ExecuteNonQuery();
            return new Result()
            {
                IsSucceded = true,
                Message = $"The database {DatabaseName} was successfully dropped"
            };
        }
        catch (Exception ex)
        {
            return new Result()
            {
                IsSucceded = false,
                Message = $"Failed to drop the database {DatabaseName} > {ex.Message}"
            };
        }
    }
    
    public static Result CreateDatabase()
    {
        if (_connection == null)
        {
            return new Result()
            {
                IsSucceded = false,
                Message = "Connection is not available"
            };
        }
        var cmd = new SqlCommand();
        cmd.Connection = Connection;
        cmd.CommandText = CreateDatabaseCommandText;
        cmd.CommandType = System.Data.CommandType.Text;
        try
        {
            cmd.ExecuteNonQuery();
            return new Result()
            {
                IsSucceded = true,
                Message = $"The database {DatabaseName} was successfully created"
            };
        }
        catch (Exception ex)
        {
            return new Result()
            {
                IsSucceded = false,
                Message = $"Failed to create the database {DatabaseName} > {ex.Message}"
            };
        }
    }

    public static Result ChangeDatabase()
    {
        if (_connection == null)
        {
            return new Result()
            {
                IsSucceded = false,
                Message = "Connection is not available"
            };
        }

        try
        {
            _connection?.ChangeDatabase(DatabaseName);
            return new Result()
            {
                IsSucceded = true,
                Message = $"Successfully changed current database to {DatabaseName}"
            };
        }
        catch (Exception ex)
        {
            return new Result()
            {
                IsSucceded = false,
                Message = $"Failed to change database > {ex.Message}"
            };
        }
    }

    public static List<string> Tables
    {
        get
        {
            var result = new List<string>();
            if (_connection == null) return result;
 
            string?[] restrictions = new string?[3];
            restrictions[0] = null;//database
            restrictions[1] = "dbo";//owner
            restrictions[2] = null; //table name
            DataTable? dt = _connection?.GetSchema("Tables", restrictions);
            if (dt != null)
            {
                foreach (DataRow row in dt.Rows)
                {
                    string tname = (string)row["TABLE_NAME"];
                    if (!tname.Equals("sysdiagrams"))
                        result.Add(tname);
                }
            }
            return result;
        }
    }
    public static Result CreateTable(string tableName, string script)
    {
        if (_connection == null)
        {
            return new Result()
            {
                IsSucceded = false,
                Message = "Connection is not available"
            };
        }

        var cmd = new SqlCommand();
        cmd.Connection = _connection;
        cmd.CommandText = script;
        cmd.CommandType = System.Data.CommandType.Text;
        try
        {
            cmd.ExecuteNonQuery();
            return new Result()
            {
                IsSucceded = true,
                Message = $"Successfully created the table {tableName}"
            };
        }
        catch (Exception ex)
        {
            return new Result()
            {
                IsSucceded = false,
                Message = $"Failed to create table > {ex.Message}"
            };
        }
    }
}
