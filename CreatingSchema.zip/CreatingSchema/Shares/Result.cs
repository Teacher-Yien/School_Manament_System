﻿namespace Shares;

public class Result
{
    public  bool IsSucceded { get; set; } = false;
    public string? Message { get; set; } = default;
}
