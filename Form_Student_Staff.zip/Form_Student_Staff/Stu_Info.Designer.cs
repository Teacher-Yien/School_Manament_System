﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.txtStuID = new System.Windows.Forms.TextBox();
            this.txtStuNameKH = new System.Windows.Forms.TextBox();
            this.txtStuNameEN = new System.Windows.Forms.TextBox();
            this.txtBirthPlace = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtPers = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.txtFather = new System.Windows.Forms.TextBox();
            this.txtMother = new System.Windows.Forms.TextBox();
            this.txtPriPer = new System.Windows.Forms.TextBox();
            this.txtSecPer = new System.Windows.Forms.TextBox();
            this.txtHighPer = new System.Windows.Forms.TextBox();
            this.txtPriSchool = new System.Windows.Forms.TextBox();
            this.txtSecSchool = new System.Windows.Forms.TextBox();
            this.txtHighSchool = new System.Windows.Forms.TextBox();
            this.checkScholarship = new System.Windows.Forms.CheckBox();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.dtpStu = new System.Windows.Forms.DateTimePicker();
            this.lstStu = new System.Windows.Forms.ListBox();
            this.btnInsert = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.cboGender = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("!Khmer OS Siemreap", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "ស្វែងរកនិស្សិត";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(247, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "លេខសម្គាល់៖";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(473, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "ឈ្មោះជាអក្សរខ្មែរ: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(247, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(140, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "ឈ្មោះជាអក្សរឡាតាំង: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(247, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "ភេទ: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(247, 160);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 24);
            this.label6.TabIndex = 5;
            this.label6.Text = "ទីកន្លែងកំណើត:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(458, 113);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 24);
            this.label7.TabIndex = 6;
            this.label7.Text = "ថ្ងៃខែឆ្នាំកំណើត: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(247, 211);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 24);
            this.label8.TabIndex = 7;
            this.label8.Text = "អ៊ីម៉ែល: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(618, 211);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 24);
            this.label9.TabIndex = 8;
            this.label9.Text = "ឆ្នាំសិក្សា: ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(247, 261);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 24);
            this.label10.TabIndex = 9;
            this.label10.Text = "អាហារូបករណ៍: ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(437, 262);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 24);
            this.label11.TabIndex = 10;
            this.label11.Text = "ភាគរយ: ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(247, 310);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 24);
            this.label12.TabIndex = 11;
            this.label12.Text = "អាសយដ្ឋាន: ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(247, 364);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(88, 24);
            this.label13.TabIndex = 12;
            this.label13.Text = "លេខទូរសព្ទ: ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(506, 364);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(113, 24);
            this.label14.TabIndex = 13;
            this.label14.Text = "លេខទំនាក់ទំនង: ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(247, 417);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 24);
            this.label15.TabIndex = 14;
            this.label15.Text = "លេខឪពុក: ";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(535, 417);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 24);
            this.label16.TabIndex = 15;
            this.label16.Text = "លេខម្តាយ: ";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(14, 467);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(113, 24);
            this.label17.TabIndex = 16;
            this.label17.Text = "មកពីបឋមសិក្សា: ";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(14, 514);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(122, 24);
            this.label18.TabIndex = 17;
            this.label18.Text = "មកពីអនុវិទ្យាល័យ: ";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(14, 561);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(102, 24);
            this.label19.TabIndex = 18;
            this.label19.Text = "មកពីវិទ្យាល័យ: ";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(545, 467);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(67, 24);
            this.label20.TabIndex = 19;
            this.label20.Text = "ឆ្នាំសិក្សា: ";
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.Location = new System.Drawing.Point(16, 60);
            this.txtSearch.Multiline = true;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(210, 30);
            this.txtSearch.TabIndex = 22;
            // 
            // txtStuID
            // 
            this.txtStuID.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStuID.Location = new System.Drawing.Point(342, 19);
            this.txtStuID.Multiline = true;
            this.txtStuID.Name = "txtStuID";
            this.txtStuID.Size = new System.Drawing.Size(122, 30);
            this.txtStuID.TabIndex = 23;
            // 
            // txtStuNameKH
            // 
            this.txtStuNameKH.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStuNameKH.Location = new System.Drawing.Point(582, 19);
            this.txtStuNameKH.Multiline = true;
            this.txtStuNameKH.Name = "txtStuNameKH";
            this.txtStuNameKH.Size = new System.Drawing.Size(194, 30);
            this.txtStuNameKH.TabIndex = 24;
            // 
            // txtStuNameEN
            // 
            this.txtStuNameEN.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStuNameEN.Location = new System.Drawing.Point(382, 62);
            this.txtStuNameEN.Multiline = true;
            this.txtStuNameEN.Name = "txtStuNameEN";
            this.txtStuNameEN.Size = new System.Drawing.Size(240, 30);
            this.txtStuNameEN.TabIndex = 25;
            // 
            // txtBirthPlace
            // 
            this.txtBirthPlace.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBirthPlace.Location = new System.Drawing.Point(342, 154);
            this.txtBirthPlace.Multiline = true;
            this.txtBirthPlace.Name = "txtBirthPlace";
            this.txtBirthPlace.Size = new System.Drawing.Size(421, 30);
            this.txtBirthPlace.TabIndex = 26;
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(342, 204);
            this.txtEmail.Multiline = true;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(261, 30);
            this.txtEmail.TabIndex = 27;
            // 
            // txtPers
            // 
            this.txtPers.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPers.Location = new System.Drawing.Point(503, 255);
            this.txtPers.Multiline = true;
            this.txtPers.Name = "txtPers";
            this.txtPers.Size = new System.Drawing.Size(273, 30);
            this.txtPers.TabIndex = 28;
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(342, 304);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(434, 30);
            this.txtAddress.TabIndex = 29;
            // 
            // txtPhone
            // 
            this.txtPhone.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhone.Location = new System.Drawing.Point(342, 358);
            this.txtPhone.Multiline = true;
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(159, 30);
            this.txtPhone.TabIndex = 30;
            // 
            // txtContact
            // 
            this.txtContact.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContact.Location = new System.Drawing.Point(611, 358);
            this.txtContact.Multiline = true;
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(165, 30);
            this.txtContact.TabIndex = 31;
            // 
            // txtFather
            // 
            this.txtFather.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFather.Location = new System.Drawing.Point(342, 411);
            this.txtFather.Multiline = true;
            this.txtFather.Name = "txtFather";
            this.txtFather.Size = new System.Drawing.Size(176, 30);
            this.txtFather.TabIndex = 32;
            // 
            // txtMother
            // 
            this.txtMother.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMother.Location = new System.Drawing.Point(611, 411);
            this.txtMother.Multiline = true;
            this.txtMother.Name = "txtMother";
            this.txtMother.Size = new System.Drawing.Size(165, 30);
            this.txtMother.TabIndex = 33;
            // 
            // txtPriPer
            // 
            this.txtPriPer.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPriPer.Location = new System.Drawing.Point(611, 459);
            this.txtPriPer.Multiline = true;
            this.txtPriPer.Name = "txtPriPer";
            this.txtPriPer.Size = new System.Drawing.Size(165, 30);
            this.txtPriPer.TabIndex = 34;
            // 
            // txtSecPer
            // 
            this.txtSecPer.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSecPer.Location = new System.Drawing.Point(611, 505);
            this.txtSecPer.Multiline = true;
            this.txtSecPer.Name = "txtSecPer";
            this.txtSecPer.Size = new System.Drawing.Size(165, 30);
            this.txtSecPer.TabIndex = 35;
            // 
            // txtHighPer
            // 
            this.txtHighPer.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHighPer.Location = new System.Drawing.Point(611, 552);
            this.txtHighPer.Multiline = true;
            this.txtHighPer.Name = "txtHighPer";
            this.txtHighPer.Size = new System.Drawing.Size(165, 30);
            this.txtHighPer.TabIndex = 36;
            // 
            // txtPriSchool
            // 
            this.txtPriSchool.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPriSchool.Location = new System.Drawing.Point(157, 460);
            this.txtPriSchool.Multiline = true;
            this.txtPriSchool.Name = "txtPriSchool";
            this.txtPriSchool.Size = new System.Drawing.Size(374, 30);
            this.txtPriSchool.TabIndex = 37;
            // 
            // txtSecSchool
            // 
            this.txtSecSchool.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSecSchool.Location = new System.Drawing.Point(157, 505);
            this.txtSecSchool.Multiline = true;
            this.txtSecSchool.Name = "txtSecSchool";
            this.txtSecSchool.Size = new System.Drawing.Size(374, 30);
            this.txtSecSchool.TabIndex = 38;
            // 
            // txtHighSchool
            // 
            this.txtHighSchool.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHighSchool.Location = new System.Drawing.Point(157, 552);
            this.txtHighSchool.Multiline = true;
            this.txtHighSchool.Name = "txtHighSchool";
            this.txtHighSchool.Size = new System.Drawing.Size(374, 30);
            this.txtHighSchool.TabIndex = 39;
            // 
            // checkScholarship
            // 
            this.checkScholarship.AutoSize = true;
            this.checkScholarship.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkScholarship.Location = new System.Drawing.Point(355, 266);
            this.checkScholarship.Name = "checkScholarship";
            this.checkScholarship.Size = new System.Drawing.Size(15, 14);
            this.checkScholarship.TabIndex = 40;
            this.checkScholarship.UseVisualStyleBackColor = true;
            // 
            // txtYear
            // 
            this.txtYear.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtYear.Location = new System.Drawing.Point(681, 204);
            this.txtYear.Multiline = true;
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(95, 30);
            this.txtYear.TabIndex = 41;
            // 
            // dtpStu
            // 
            this.dtpStu.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpStu.Location = new System.Drawing.Point(563, 109);
            this.dtpStu.Name = "dtpStu";
            this.dtpStu.Size = new System.Drawing.Size(213, 31);
            this.dtpStu.TabIndex = 44;
            // 
            // lstStu
            // 
            this.lstStu.FormattingEnabled = true;
            this.lstStu.Location = new System.Drawing.Point(16, 98);
            this.lstStu.Name = "lstStu";
            this.lstStu.Size = new System.Drawing.Size(210, 329);
            this.lstStu.TabIndex = 45;
            // 
            // btnInsert
            // 
            this.btnInsert.Font = new System.Drawing.Font("!Khmer OS Siemreap", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsert.Location = new System.Drawing.Point(18, 612);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(189, 36);
            this.btnInsert.TabIndex = 46;
            this.btnInsert.Text = "បន្ថែម(កំណត់ទីតាំង)";
            this.btnInsert.UseVisualStyleBackColor = true;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Font = new System.Drawing.Font("!Khmer OS Siemreap", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Location = new System.Drawing.Point(237, 612);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(110, 36);
            this.btnUpdate.TabIndex = 47;
            this.btnUpdate.Text = "កែតម្រូវ";
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // btnNew
            // 
            this.btnNew.Font = new System.Drawing.Font("!Khmer OS Siemreap", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.Location = new System.Drawing.Point(396, 612);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(149, 36);
            this.btnNew.TabIndex = 48;
            this.btnNew.Text = "បន្ថែមព័ត៌មានថ្មី";
            this.btnNew.UseVisualStyleBackColor = true;
            // 
            // btnLogOut
            // 
            this.btnLogOut.Font = new System.Drawing.Font("!Khmer OS Siemreap", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogOut.Location = new System.Drawing.Point(642, 612);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(110, 36);
            this.btnLogOut.TabIndex = 49;
            this.btnLogOut.Text = "ចាកចេញ";
            this.btnLogOut.UseVisualStyleBackColor = true;
            // 
            // cboGender
            // 
            this.cboGender.Font = new System.Drawing.Font("Khmer OS System", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboGender.FormattingEnabled = true;
            this.cboGender.Location = new System.Drawing.Point(342, 109);
            this.cboGender.Name = "cboGender";
            this.cboGender.Size = new System.Drawing.Size(97, 32);
            this.cboGender.TabIndex = 50;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(545, 514);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(67, 24);
            this.label21.TabIndex = 51;
            this.label21.Text = "ឆ្នាំសិក្សា: ";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("!Khmer OS Siemreap", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(545, 561);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(67, 24);
            this.label22.TabIndex = 52;
            this.label22.Text = "ឆ្នាំសិក្សា: ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(788, 673);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.cboGender);
            this.Controls.Add(this.btnLogOut);
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.lstStu);
            this.Controls.Add(this.dtpStu);
            this.Controls.Add(this.txtYear);
            this.Controls.Add(this.checkScholarship);
            this.Controls.Add(this.txtHighSchool);
            this.Controls.Add(this.txtSecSchool);
            this.Controls.Add(this.txtPriSchool);
            this.Controls.Add(this.txtHighPer);
            this.Controls.Add(this.txtSecPer);
            this.Controls.Add(this.txtPriPer);
            this.Controls.Add(this.txtMother);
            this.Controls.Add(this.txtFather);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtPers);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtBirthPlace);
            this.Controls.Add(this.txtStuNameEN);
            this.Controls.Add(this.txtStuNameKH);
            this.Controls.Add(this.txtStuID);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "ព័ត៌មាននិស្សិត";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.TextBox txtStuID;
        private System.Windows.Forms.TextBox txtStuNameKH;
        private System.Windows.Forms.TextBox txtStuNameEN;
        private System.Windows.Forms.TextBox txtBirthPlace;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtPers;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.TextBox txtFather;
        private System.Windows.Forms.TextBox txtMother;
        private System.Windows.Forms.TextBox txtPriPer;
        private System.Windows.Forms.TextBox txtSecPer;
        private System.Windows.Forms.TextBox txtHighPer;
        private System.Windows.Forms.TextBox txtPriSchool;
        private System.Windows.Forms.TextBox txtSecSchool;
        private System.Windows.Forms.TextBox txtHighSchool;
        private System.Windows.Forms.CheckBox checkScholarship;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.DateTimePicker dtpStu;
        private System.Windows.Forms.ListBox lstStu;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.ComboBox cboGender;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
    }
}

