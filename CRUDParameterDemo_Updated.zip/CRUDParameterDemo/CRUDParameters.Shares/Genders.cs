﻿namespace EnrollLibrary
{
    public enum Genders { Female = 0, Male = 1 };
}