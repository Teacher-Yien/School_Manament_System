﻿namespace EnrollLibrary
{
    public enum EntityTypes { None=0, Students=1, Courses=2, Enrollings=4 };
    
}