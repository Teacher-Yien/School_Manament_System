﻿namespace EnrollLibrary
{
    public class Procedure
    {
        public string Name { get; set; } = default!;
        public string Script { get; set; } = default!;
    }
}