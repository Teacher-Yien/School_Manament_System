﻿using System.Diagnostics;
using System.IO.Enumeration;
using System.Reflection.PortableExecutable;

internal class Program
{
    private static void Main(string[] args)
    {
        string filename = "test.bin";
        //WritingBinaryData(filename);
        //ReadingBinaryData(filename);

        string expFile = "expenses.dat";
        Expense[] exps = new Expense[]
        {
            new(){Descr = "Fooding", Amount=100},
            new(){Descr = "Studying", Amount=200},
            new(){Descr = "Shopping", Amount=500},
            new(){Descr = "Picnics", Amount=150},
            new(){Descr = "Others", Amount=50},
        };
        //WritingExpenses(expFile, exps);
        var result= ReadingExpenses(expFile);
        Console.WriteLine("Here are all expenses read");
        foreach(var exp in result.OrderByDescending(e=>e.Amount))
        {
            Console.WriteLine($"{exp.Amount, 12:C2}>{exp.Descr}");
        }
    }
    static List<Expense> ReadingExpenses(string filename)
    {
        var result = new List<Expense>();
        try
        {

            using (FileStream fs = new FileStream(filename, FileMode.Open))
            {
                using(var reader =new BinaryReader(fs))
                {
                    while (true)
                    {
                        try
                        {
                            string descr = reader.ReadString();
                            double amount = reader.ReadDouble();
                            result.Add(new Expense()
                            { Amount = amount, Descr = descr });
                        }
                        catch(EndOfStreamException ) { break; }
                    }
                }
            }

        }
        catch(Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
        return result;
    }
    static void WritingExpenses(string filename, Expense[] exps)
    {
        try
        {
            using (FileStream fs = new FileStream(filename, FileMode.Create))
            {
                using (BinaryWriter writer = new BinaryWriter(fs))
                {
                    foreach(var exp  in exps)
                    {
                        writer.Write(exp.Descr);
                        writer.Write(exp.Amount);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
    }
    static void WritingBinaryData(string filename)
    {
        try
        {
            using (FileStream fs = new FileStream(filename, FileMode.Create))
            {
                using (BinaryWriter writer = new BinaryWriter(fs))
                {
                    int intValue = 42;
                    double doubleValue = 3.14159;
                    string stringValue = "Hello, world!";
                    writer.Write(intValue);
                    writer.Write(doubleValue);
                    writer.Write(stringValue);
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
    }
    static void ReadingBinaryData(string filename)
    {
        try
        {
            using (FileStream fs = new FileStream(filename, FileMode.Open))
            {
                using (BinaryReader reader = new BinaryReader(fs))
                {
                    fs.Seek(sizeof(int), SeekOrigin.Begin);
                    double doubleValue = reader.ReadDouble();
                    
                    string stringValue = reader.ReadString();
                    fs.Seek(0, SeekOrigin.Begin);
                    int intValue = reader.ReadInt32();
                    Console.WriteLine(
                    $"int: {intValue}, double: {doubleValue}, string: {stringValue}");
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
    }
}
public class Expense
{
    public string Descr { get; set; }
    public double Amount { get; set; }
}
    